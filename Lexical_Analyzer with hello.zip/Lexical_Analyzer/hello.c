/*
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
int main()
{
    int arr[100];
    int num = 10;
    int num1a = 0x123;
    int num2 = 20;
    float f1 = 20.20;
    int sum;
    sum = num + num2;
    sum += num;
    sum = num / num2;
    char ch = 'A';
    num = num++;
    printf("Hello\n");
    printf("sum = %d", sum);
    return 0;
}


